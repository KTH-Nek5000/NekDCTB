typedef struct _send_get_atom_msg {
    char *atom_string;
    atom_t atom;
} send_get_atom_msg, *send_get_atom_msg_ptr;


#define UDP_PORT 4444
#define TCP_PORT 4445

