This is a copy of the upstream KWSys repo located at
https://gitlab.kitware.com/utils/kwsys.git.  Do not make changes directly to
this repo but instead to the upstream repository.  Update this copy of KWSys by
running the update.sh script.
