This is a copy of the upstream pugixml library located at
https://github.com/zeux/pugixml. Do not make changes directly to this repo
but instead to the upstream repository.  Update this copy of pugixml by running
the update.sh script.
