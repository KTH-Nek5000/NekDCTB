This is a copy of the upstream Google C++ test framework located at
https://github.com/google/googletest. Do not make changes directly to this repo
but instead to the upstream repository.  Update this copy of GTest by running
the update.sh script.
