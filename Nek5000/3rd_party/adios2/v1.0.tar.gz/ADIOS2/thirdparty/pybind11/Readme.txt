This is a copy of the upstream pybind11 library located at for interfacing python and C++11
https://github.com/pybind/pybind11. Do not make changes directly to this repo
but instead to the upstream repository.  Update this copy of pybind11 by running
the update.sh script.
